export type ParallaxProps = {
  title: string;
  subtitle?: string;
  /** Optional photo in public/images/, e.g. "images/dhaka.jpg". Leave empty for the stylized background. */
  imageSrc?: string;
};

export type NewspaperProps = {
  headline: string;
  source?: string;
  date?: string;
  body: string;
  /** A phrase that appears inside `body`; it gets the animated marker highlight. */
  highlight: string;
};

export type KineticQuoteProps = {
  quote: string;
  author?: string;
};

export type ChartItem = {label: string; value: number};
export type DataChartProps = {
  title: string;
  items: ChartItem[];
  unit?: string;
  source?: string;
};

export type TimelineEvent = {
  date: string;
  title: string;
  description?: string;
};
export type TimelineProps = {
  title?: string;
  orientation?: 'horizontal' | 'vertical';
  events: TimelineEvent[];
};

export type ComparisonSide = {
  label: string;
  value?: string;
  points: string[];
};
export type SplitComparisonProps = {
  title?: string;
  left: ComparisonSide;
  right: ComparisonSide;
};

export type MapZoomProps = {
  locationLabel: string;
  subLabel?: string;
  /** Pin position on the map, 0-100 (percent of width / height). */
  pinX?: number;
  pinY?: number;
  /** Final zoom level, default 2.4 */
  zoom?: number;
};

export type SceneSpec =
  | {type: 'parallax'; props: ParallaxProps}
  | {type: 'newspaper'; props: NewspaperProps}
  | {type: 'quote'; props: KineticQuoteProps}
  | {type: 'chart'; props: DataChartProps}
  | {type: 'timeline'; props: TimelineProps}
  | {type: 'comparison'; props: SplitComparisonProps}
  | {type: 'map'; props: MapZoomProps};

/** One entry of src/generated/scenes.json (written by scripts/generate_voice.py). */
export type GeneratedScene = SceneSpec & {
  narration?: string;
  /** File inside public/, e.g. "audio/scene_01.mp3". null = no narration. */
  audio: string | null;
  durationInFrames: number;
};

export type GeneratedTimeline = {
  title: string;
  fps: number;
  scenes: GeneratedScene[];
};
