import React from 'react';
import {AbsoluteFill, Audio, Series, getStaticFiles, interpolate, staticFile, useCurrentFrame, useVideoConfig} from 'remotion';
import {ParallaxScene} from './components/ParallaxScene';
import {NewspaperHighlight} from './components/NewspaperHighlight';
import {KineticQuote} from './components/KineticQuote';
import {DataChart} from './components/DataChart';
import {TimelineScene} from './components/TimelineScene';
import {SplitComparison} from './components/SplitComparison';
import {MapZoomScene} from './components/MapZoomScene';
import {theme, withAlpha} from './theme';
import timeline from './generated/scenes.json';
import type {GeneratedScene, GeneratedTimeline} from './types';

const data = timeline as unknown as GeneratedTimeline;

/** SFX files are optional: if a file is missing from public/sfx/, it is silently skipped (render never breaks). */
const hasStaticFile = (name: string): boolean => {
  try {
    return getStaticFiles().some((f) => f.name === name);
  } catch {
    return false;
  }
};

const Sfx: React.FC<{file: string; volume?: number}> = ({file, volume = 0.5}) =>
  hasStaticFile(`sfx/${file}`) ? <Audio src={staticFile(`sfx/${file}`)} volume={volume} /> : null;

const renderScene = (scene: GeneratedScene): React.ReactNode => {
  switch (scene.type) {
    case 'parallax':
      return <ParallaxScene {...scene.props} />;
    case 'newspaper':
      return <NewspaperHighlight {...scene.props} />;
    case 'quote':
      return <KineticQuote {...scene.props} />;
    case 'chart':
      return <DataChart {...scene.props} />;
    case 'timeline':
      return <TimelineScene {...scene.props} />;
    case 'comparison':
      return <SplitComparison {...scene.props} />;
    case 'map':
      return <MapZoomScene {...scene.props} />;
    default:
      return null;
  }
};

const sceneSfx = (scene: GeneratedScene): React.ReactNode => {
  switch (scene.type) {
    case 'newspaper':
      return <Sfx file="paper_flip.mp3" volume={0.6} />;
    case 'quote':
    case 'map':
      return <Sfx file="riser.mp3" volume={0.35} />;
    default:
      return <Sfx file="whoosh.mp3" volume={0.45} />;
  }
};

const SceneFrame: React.FC<{scene: GeneratedScene}> = ({scene}) => {
  const frame = useCurrentFrame();
  const {durationInFrames} = useVideoConfig();
  const FADE = 10;
  const opacity = interpolate(frame, [0, FADE, durationInFrames - FADE, durationInFrames], [0, 1, 1, 0], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
  });
  return (
    <AbsoluteFill style={{opacity}}>
      {renderScene(scene)}
      {scene.audio ? <Audio src={staticFile(scene.audio)} /> : null}
      {sceneSfx(scene)}
    </AbsoluteFill>
  );
};

/** Channel tag (top-left) + watermark (bottom-right). Both come from brand-config.json. */
const BrandOverlay: React.FC = () => (
  <AbsoluteFill style={{pointerEvents: 'none'}}>
    <div
      style={{
        position: 'absolute',
        left: 56,
        top: 44,
        display: 'flex',
        alignItems: 'center',
        gap: 14,
        fontFamily: theme.fontSans,
        fontWeight: 600,
        fontSize: 30,
        color: 'rgba(255,255,255,0.8)',
      }}
    >
      <div
        style={{
          width: 14,
          height: 14,
          borderRadius: 7,
          background: theme.primary,
          boxShadow: `0 0 16px ${withAlpha(theme.primary, 0.9)}`,
        }}
      />
      {theme.channelName}
    </div>
    {theme.watermarkText ? (
      <div
        style={{
          position: 'absolute',
          right: 56,
          bottom: 40,
          fontFamily: theme.fontSans,
          fontSize: 28,
          color: 'rgba(255,255,255,0.45)',
        }}
      >
        {theme.watermarkText}
      </div>
    ) : null}
  </AbsoluteFill>
);

export const Documentary: React.FC = () => {
  return (
    <AbsoluteFill style={{background: theme.background}}>
      {hasStaticFile('sfx/bg_dark.mp3') ? <Audio src={staticFile('sfx/bg_dark.mp3')} volume={0.12} loop /> : null}
      <Series>
        {data.scenes.map((scene, i) => (
          <Series.Sequence key={i} durationInFrames={scene.durationInFrames}>
            <SceneFrame scene={scene} />
          </Series.Sequence>
        ))}
      </Series>
      <BrandOverlay />
    </AbsoluteFill>
  );
};
