import React from 'react';
import {AbsoluteFill, Easing, interpolate, spring, useCurrentFrame, useVideoConfig} from 'remotion';
import {theme, toBn, withAlpha} from '../theme';
import type {TimelineEvent, TimelineProps} from '../types';

const easeOut = Easing.bezier(0.16, 1, 0.3, 1);

const Card: React.FC<{event: TimelineEvent; progress: number; width: number; align?: 'left' | 'right' | 'center'}> = ({
  event,
  progress,
  width,
  align = 'left',
}) => (
  <div
    style={{
      width,
      padding: '24px 28px',
      background: theme.surface,
      border: `1.5px solid ${theme.surfaceBorder}`,
      borderRadius: 20,
      backdropFilter: 'blur(6px)',
      textAlign: align,
      opacity: progress,
      transform: `translateY(${(1 - progress) * 36}px)`,
      boxShadow: '0 20px 60px rgba(0,0,0,0.4)',
    }}
  >
    <div style={{fontFamily: theme.fontSans, fontWeight: 800, fontSize: 56, color: theme.primary, lineHeight: 1.2}}>
      {toBn(event.date)}
    </div>
    <div style={{fontFamily: theme.fontSans, fontWeight: 700, fontSize: 38, color: theme.text, lineHeight: 1.4, marginTop: 6}}>
      {event.title}
    </div>
    {event.description ? (
      <div style={{fontFamily: theme.fontSans, fontSize: 28, color: theme.textDim, lineHeight: 1.55, marginTop: 8}}>
        {event.description}
      </div>
    ) : null}
  </div>
);

const Dot: React.FC<{progress: number}> = ({progress}) => (
  <div
    style={{
      width: 30,
      height: 30,
      borderRadius: 15,
      background: theme.primary,
      boxShadow: `0 0 ${30 * progress}px ${withAlpha(theme.primary, 0.9)}`,
      transform: `scale(${progress})`,
      border: `5px solid ${theme.background}`,
    }}
  />
);

export const TimelineScene: React.FC<TimelineProps> = ({title, orientation = 'horizontal', events}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const n = events.length;

  const titleIn = interpolate(frame, [0, 22], [0, 1], {extrapolateRight: 'clamp', easing: easeOut});
  const lineProgress = interpolate(frame, [10, 10 + n * 22], [0, 1], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
    easing: Easing.inOut(Easing.cubic),
  });
  const evProgress = (i: number) => spring({frame: frame - (18 + i * 22), fps, config: {damping: 18, stiffness: 120}});

  const header = title ? (
    <div
      style={{
        position: 'absolute',
        left: 140,
        top: 118,
        fontFamily: theme.fontSans,
        fontWeight: 800,
        fontSize: 72,
        color: theme.text,
        opacity: titleIn,
        transform: `translateY(${(1 - titleIn) * 24}px)`,
      }}
    >
      {title}
      <div style={{width: 120, height: 7, background: theme.primary, borderRadius: 4, marginTop: 14}} />
    </div>
  ) : null;

  if (orientation === 'vertical') {
    const top = title ? 300 : 130;
    const usable = 1080 - top - 90;
    const step = usable / Math.max(n, 1);
    const cardW = 640;
    return (
      <AbsoluteFill style={{background: theme.background}}>
        <AbsoluteFill
          style={{background: `radial-gradient(ellipse at 50% 0%, ${withAlpha(theme.secondary, 0.14)}, transparent 60%)`}}
        />
        {header}
        <div
          style={{
            position: 'absolute',
            left: 960 - 3,
            top,
            width: 6,
            height: usable * lineProgress,
            background: `linear-gradient(180deg, ${theme.primary}, ${theme.secondary})`,
            borderRadius: 3,
          }}
        />
        {events.map((ev, i) => {
          const p = evProgress(i);
          const y = top + i * step + step / 2;
          const left = i % 2 === 0;
          return (
            <React.Fragment key={i}>
              <div style={{position: 'absolute', left: 960 - 15, top: y - 15}}>
                <Dot progress={Math.min(1, p)} />
              </div>
              <div
                style={{
                  position: 'absolute',
                  top: y - step * 0.42,
                  ...(left ? {right: 960 + 50} : {left: 960 + 50}),
                }}
              >
                <Card event={ev} progress={Math.min(1, p)} width={cardW} align={left ? 'right' : 'left'} />
              </div>
            </React.Fragment>
          );
        })}
      </AbsoluteFill>
    );
  }

  // horizontal
  const left = 160;
  const right = 160;
  const lineY = 590;
  const usableW = 1920 - left - right;
  const step = usableW / Math.max(n, 1);
  const cardW = Math.min(420, step * 1.5);
  return (
    <AbsoluteFill style={{background: theme.background}}>
      <AbsoluteFill
        style={{background: `radial-gradient(ellipse at 50% 100%, ${withAlpha(theme.primary, 0.14)}, transparent 60%)`}}
      />
      {header}
      <div
        style={{
          position: 'absolute',
          left,
          top: lineY - 3,
          width: usableW * lineProgress,
          height: 6,
          background: `linear-gradient(90deg, ${theme.primary}, ${theme.secondary})`,
          borderRadius: 3,
        }}
      />
      {events.map((ev, i) => {
        const p = Math.min(1, evProgress(i));
        const cx = left + i * step + step / 2;
        const above = i % 2 === 0;
        return (
          <React.Fragment key={i}>
            <div style={{position: 'absolute', left: cx - 15, top: lineY - 15}}>
              <Dot progress={p} />
            </div>
            <div
              style={{
                position: 'absolute',
                left: cx - cardW / 2,
                ...(above ? {bottom: 1080 - lineY + 50} : {top: lineY + 50}),
              }}
            >
              <Card event={ev} progress={p} width={cardW} align="center" />
            </div>
          </React.Fragment>
        );
      })}
    </AbsoluteFill>
  );
};
