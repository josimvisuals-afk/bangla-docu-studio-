import React from 'react';
import {AbsoluteFill, Easing, interpolate, useCurrentFrame} from 'remotion';
import {theme, toBn, withAlpha} from '../theme';
import type {DataChartProps} from '../types';

const easeOut = Easing.bezier(0.16, 1, 0.3, 1);

const formatBn = (n: number): string =>
  toBn(Number.isInteger(n) ? n.toLocaleString('en-US') : n.toLocaleString('en-US', {maximumFractionDigits: 1}));

export const DataChart: React.FC<DataChartProps> = ({title, items, unit, source}) => {
  const frame = useCurrentFrame();
  const max = Math.max(...items.map((i) => i.value), 1);
  const topIndex = items.reduce((best, it, i) => (it.value > items[best].value ? i : best), 0);

  const titleIn = interpolate(frame, [0, 24], [0, 1], {extrapolateRight: 'clamp', easing: easeOut});
  const rowH = Math.min(120, 640 / Math.max(items.length, 1));

  return (
    <AbsoluteFill style={{background: theme.background, padding: '110px 150px'}}>
      <AbsoluteFill
        style={{background: `radial-gradient(ellipse at 85% 10%, ${withAlpha(theme.primary, 0.14)}, transparent 55%)`}}
      />
      <div
        style={{
          fontFamily: theme.fontSans,
          fontWeight: 800,
          fontSize: 80,
          lineHeight: 1.3,
          color: theme.text,
          opacity: titleIn,
          transform: `translateY(${(1 - titleIn) * 30}px)`,
        }}
      >
        {title}
      </div>
      <div style={{width: 140, height: 7, background: theme.primary, borderRadius: 4, margin: '20px 0 50px'}} />

      <div style={{display: 'flex', flexDirection: 'column', gap: 16}}>
        {items.map((item, i) => {
          const start = 16 + i * 9;
          const p = interpolate(frame, [start, start + 40], [0, 1], {
            extrapolateLeft: 'clamp',
            extrapolateRight: 'clamp',
            easing: easeOut,
          });
          const isTop = i === topIndex;
          const color = isTop ? theme.primary : theme.secondary;
          return (
            <div key={i} style={{display: 'flex', alignItems: 'center', height: rowH, opacity: Math.min(1, p * 2)}}>
              <div
                style={{
                  width: 330,
                  fontFamily: theme.fontSans,
                  fontSize: 44,
                  fontWeight: 600,
                  color: theme.text,
                  textAlign: 'right',
                  paddingRight: 34,
                }}
              >
                {item.label}
              </div>
              <div style={{flex: 1, height: rowH * 0.6, background: theme.surface, borderRadius: 14, position: 'relative'}}>
                <div
                  style={{
                    height: '100%',
                    width: `${(item.value / max) * 100 * p}%`,
                    background: `linear-gradient(90deg, ${withAlpha(color, 0.7)}, ${color})`,
                    borderRadius: 14,
                    boxShadow: isTop ? `0 0 40px ${withAlpha(theme.primary, 0.5)}` : 'none',
                  }}
                />
              </div>
              <div
                style={{
                  width: 300,
                  paddingLeft: 30,
                  fontFamily: theme.fontSans,
                  fontSize: 46,
                  fontWeight: 800,
                  color: isTop ? theme.primary : theme.text,
                }}
              >
                {formatBn(item.value * p)}
                {unit ? <span style={{fontSize: 32, fontWeight: 400, color: theme.textDim}}> {unit}</span> : null}
              </div>
            </div>
          );
        })}
      </div>

      {source ? (
        <div
          style={{
            position: 'absolute',
            left: 150,
            bottom: 70,
            fontFamily: theme.fontSans,
            fontSize: 30,
            color: theme.textDim,
          }}
        >
          সূত্র: {source}
        </div>
      ) : null}
    </AbsoluteFill>
  );
};
