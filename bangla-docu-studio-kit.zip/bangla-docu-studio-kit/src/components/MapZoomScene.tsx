import React from 'react';
import {AbsoluteFill, Easing, interpolate, spring, useCurrentFrame, useVideoConfig} from 'remotion';
import {theme, withAlpha} from '../theme';
import type {MapZoomProps} from '../types';

const easeInOut = Easing.bezier(0.65, 0, 0.35, 1);

/**
 * Stylized dark "map": dot grid, soft land masses, river lines and contour rings.
 * It is deliberately abstract (not a real cartographic outline) so it never shows wrong borders.
 * Pin position comes from props, so the same map works for any location.
 */
const StylizedMap: React.FC = () => {
  const dots: React.ReactNode[] = [];
  for (let x = 40; x < 1920; x += 48) {
    for (let y = 40; y < 1080; y += 48) {
      dots.push(<circle key={`${x}-${y}`} cx={x} cy={y} r={1.6} fill="rgba(255,255,255,0.1)" />);
    }
  }
  return (
    <svg width={1920} height={1080} viewBox="0 0 1920 1080" style={{position: 'absolute', inset: 0}}>
      <rect width={1920} height={1080} fill={theme.background} />
      {dots}
      <path
        d="M160 380 C 320 180, 640 140, 880 250 C 1120 360, 1180 120, 1460 190 C 1700 250, 1840 430, 1760 620 C 1690 800, 1480 900, 1240 880 C 1040 860, 940 960, 720 920 C 460 870, 200 800, 150 620 C 110 520, 110 440, 160 380 Z"
        fill="rgba(255,255,255,0.045)"
        stroke="rgba(255,255,255,0.16)"
        strokeWidth={2}
      />
      <path
        d="M420 360 C 560 300, 760 330, 840 430 C 920 540, 800 640, 640 640 C 480 640, 360 540, 420 360 Z"
        fill="none"
        stroke="rgba(255,255,255,0.08)"
        strokeWidth={2}
      />
      <path
        d="M1100 420 C 1240 340, 1440 380, 1500 500 C 1560 620, 1420 720, 1260 700 C 1120 680, 1020 520, 1100 420 Z"
        fill="none"
        stroke="rgba(255,255,255,0.08)"
        strokeWidth={2}
      />
      {[
        'M300 160 C 420 360, 560 460, 700 540 S 940 760, 1000 940',
        'M1250 180 C 1180 360, 1280 520, 1180 680 S 1080 860, 1140 1000',
        'M760 260 C 840 420, 980 480, 1100 560 S 1300 700, 1500 880',
      ].map((d, i) => (
        <g key={i}>
          <path d={d} fill="none" stroke={withAlpha(theme.secondary, 0.18)} strokeWidth={12} strokeLinecap="round" />
          <path d={d} fill="none" stroke={withAlpha(theme.secondary, 0.55)} strokeWidth={3} strokeLinecap="round" />
        </g>
      ))}
    </svg>
  );
};

export const MapZoomScene: React.FC<MapZoomProps> = ({locationLabel, subLabel, pinX = 58, pinY = 55, zoom = 2.4}) => {
  const frame = useCurrentFrame();
  const {fps, durationInFrames} = useVideoConfig();

  const zoomEnd = Math.min(durationInFrames - 30, 110);
  const scale = interpolate(frame, [8, zoomEnd], [1, zoom], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
    easing: easeInOut,
  });

  const px = (pinX / 100) * 1920;
  const py = (pinY / 100) * 1080;

  const pinIn = spring({frame: frame - (zoomEnd - 30), fps, config: {damping: 11, stiffness: 150}});
  const labelIn = spring({frame: frame - (zoomEnd - 14), fps, config: {damping: 200}});
  const ripple = (offset: number) => {
    const t = ((frame - offset) % 60) / 60;
    return {r: 14 + t * 90, o: (1 - t) * 0.6};
  };

  return (
    <AbsoluteFill style={{background: theme.background, overflow: 'hidden'}}>
      {/* Camera: scaling around the pin keeps the pin fixed on screen while the map rushes in. */}
      <AbsoluteFill style={{transform: `scale(${scale})`, transformOrigin: `${px}px ${py}px`}}>
        <StylizedMap />
      </AbsoluteFill>

      <AbsoluteFill
        style={{background: 'radial-gradient(ellipse at center, transparent 40%, rgba(0,0,0,0.7) 100%)'}}
      />

      <svg width={1920} height={1080} style={{position: 'absolute', inset: 0}}>
        {[0, 20, 40].map((off) => {
          const {r, o} = ripple(off);
          return (
            <circle key={off} cx={px} cy={py} r={r * pinIn} fill="none" stroke={theme.primary} strokeWidth={3} opacity={o * pinIn} />
          );
        })}
        <circle cx={px} cy={py} r={60 * pinIn} fill={withAlpha(theme.primary, 0.25)} />
        <circle cx={px} cy={py} r={16 * pinIn} fill={theme.primary} stroke="#fff" strokeWidth={4} />
      </svg>

      <div
        style={{
          position: 'absolute',
          left: px + 70,
          top: py - 70,
          padding: '20px 34px',
          background: 'rgba(14,14,16,0.82)',
          border: `1.5px solid ${withAlpha(theme.primary, 0.7)}`,
          borderRadius: 18,
          opacity: labelIn,
          transform: `translateX(${(1 - labelIn) * -30}px)`,
          boxShadow: `0 0 50px ${withAlpha(theme.primary, 0.3)}`,
        }}
      >
        <div style={{fontFamily: theme.fontSans, fontWeight: 800, fontSize: 70, color: theme.text, lineHeight: 1.3}}>
          {locationLabel}
        </div>
        {subLabel ? (
          <div style={{fontFamily: theme.fontSans, fontSize: 36, color: theme.textDim, marginTop: 4}}>{subLabel}</div>
        ) : null}
      </div>
    </AbsoluteFill>
  );
};
