import React from 'react';
import {AbsoluteFill, Easing, Img, interpolate, spring, staticFile, useCurrentFrame, useVideoConfig} from 'remotion';
import {theme, withAlpha} from '../theme';
import type {ParallaxProps} from '../types';

const easeOut = Easing.bezier(0.16, 1, 0.3, 1);

/** Layered "hills" that drift at different speeds => cheap, clean parallax with no assets needed. */
const Layer: React.FC<{speed: number; y: number; color: string; seed: number; opacity: number}> = ({
  speed,
  y,
  color,
  seed,
  opacity,
}) => {
  const frame = useCurrentFrame();
  const x = -frame * speed;
  // Start and end at the same height (y=250) so the two tiled copies join without a visible seam.
  const d = `M0 250 C 200 ${120 + seed * 40}, 420 ${360 - seed * 30}, 640 ${180 + seed * 20}
    S 1000 ${320 - seed * 25}, 1280 ${150 + seed * 35} S 1700 ${330 - seed * 20}, 1920 250
    L 1920 700 L 0 700 Z`;
  return (
    <svg
      width={3840}
      height={700}
      viewBox="0 0 3840 700"
      style={{position: 'absolute', left: 0, top: y, transform: `translateX(${x % 1920}px)`, opacity}}
    >
      <path d={d} fill={color} />
      <path d={d} fill={color} transform="translate(1920 0)" />
    </svg>
  );
};

export const ParallaxScene: React.FC<ParallaxProps> = ({title, subtitle, imageSrc}) => {
  const frame = useCurrentFrame();
  const {fps, durationInFrames} = useVideoConfig();

  const zoom = interpolate(frame, [0, durationInFrames], [1.0, 1.12]);
  const panX = interpolate(frame, [0, durationInFrames], [0, -60]);

  const titleIn = spring({frame: frame - 10, fps, config: {damping: 200}});
  const subIn = spring({frame: frame - 28, fps, config: {damping: 200}});
  const barW = interpolate(frame, [4, 36], [0, 160], {extrapolateRight: 'clamp', easing: easeOut});

  return (
    <AbsoluteFill style={{background: theme.background, overflow: 'hidden'}}>
      <AbsoluteFill style={{transform: `scale(${zoom}) translateX(${panX}px)`}}>
        {imageSrc ? (
          <Img src={staticFile(imageSrc)} style={{width: '100%', height: '100%', objectFit: 'cover', opacity: 0.55}} />
        ) : (
          <>
            <AbsoluteFill
              style={{
                background: `radial-gradient(ellipse at 70% 20%, ${withAlpha(theme.primary, 0.35)}, transparent 60%),
                  radial-gradient(ellipse at 20% 80%, ${withAlpha(theme.secondary, 0.22)}, transparent 55%)`,
              }}
            />
            <Layer speed={0.25} y={330} color={withAlpha(theme.secondary, 0.16)} seed={0} opacity={1} />
            <Layer speed={0.6} y={430} color={withAlpha(theme.primary, 0.2)} seed={1} opacity={1} />
            <Layer speed={1.1} y={560} color="rgba(0,0,0,0.55)" seed={2} opacity={1} />
          </>
        )}
      </AbsoluteFill>

      <AbsoluteFill
        style={{background: 'linear-gradient(180deg, rgba(0,0,0,0.15) 0%, rgba(0,0,0,0.75) 100%)'}}
      />

      <AbsoluteFill style={{justifyContent: 'flex-end', padding: '0 140px 150px'}}>
        <div style={{width: barW, height: 8, background: theme.primary, borderRadius: 4, marginBottom: 34}} />
        <div
          style={{
            fontFamily: theme.fontSans,
            fontWeight: 800,
            fontSize: 124,
            lineHeight: 1.25,
            color: theme.text,
            maxWidth: 1500,
            opacity: titleIn,
            transform: `translateY(${(1 - titleIn) * 50}px)`,
            textShadow: '0 6px 40px rgba(0,0,0,0.6)',
          }}
        >
          {title}
        </div>
        {subtitle ? (
          <div
            style={{
              fontFamily: theme.fontSans,
              fontWeight: 400,
              fontSize: 48,
              lineHeight: 1.5,
              color: theme.textDim,
              marginTop: 18,
              maxWidth: 1400,
              opacity: subIn,
              transform: `translateY(${(1 - subIn) * 30}px)`,
            }}
          >
            {subtitle}
          </div>
        ) : null}
      </AbsoluteFill>
    </AbsoluteFill>
  );
};
