import React from 'react';
import {AbsoluteFill, Easing, interpolate, spring, useCurrentFrame, useVideoConfig} from 'remotion';
import {theme, withAlpha} from '../theme';
import type {ComparisonSide, SplitComparisonProps} from '../types';

const easeOut = Easing.bezier(0.16, 1, 0.3, 1);

const Panel: React.FC<{side: ComparisonSide; color: string; from: 'left' | 'right'}> = ({side, color, from}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const slide = interpolate(frame, [0, 30], [1, 0], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
    easing: easeOut,
  });
  const dir = from === 'left' ? -1 : 1;

  return (
    <div
      style={{
        flex: 1,
        position: 'relative',
        padding: '140px 150px 110px',
        justifyContent: 'center',
        background: `linear-gradient(${from === 'left' ? 135 : 225}deg, ${withAlpha(color, 0.28)}, ${withAlpha(color, 0.04)} 70%)`,
        transform: `translateX(${slide * dir * 900}px)`,
        display: 'flex',
        flexDirection: 'column',
        alignItems: from === 'left' ? 'flex-end' : 'flex-start',
        textAlign: from === 'left' ? 'right' : 'left',
      }}
    >
      <div
        style={{
          fontFamily: theme.fontSans,
          fontWeight: 800,
          fontSize: 96,
          color,
          lineHeight: 1.3,
          textShadow: `0 0 50px ${withAlpha(color, 0.45)}`,
        }}
      >
        {side.label}
      </div>
      {side.value ? (
        <div style={{fontFamily: theme.fontSans, fontWeight: 800, fontSize: 130, color: theme.text, lineHeight: 1.2, marginTop: 6}}>
          {side.value}
        </div>
      ) : null}
      <div style={{marginTop: 36, display: 'flex', flexDirection: 'column', gap: 22}}>
        {side.points.map((pt, i) => {
          const p = spring({frame: frame - (34 + i * 14), fps, config: {damping: 20, stiffness: 120}});
          return (
            <div
              key={i}
              style={{
                display: 'flex',
                flexDirection: from === 'left' ? 'row-reverse' : 'row',
                alignItems: 'center',
                gap: 20,
                opacity: Math.min(1, p),
                transform: `translateX(${(1 - p) * dir * 50}px)`,
              }}
            >
              <div style={{width: 16, height: 16, borderRadius: 8, background: color, flexShrink: 0}} />
              <div style={{fontFamily: theme.fontSans, fontSize: 46, fontWeight: 600, color: theme.text, lineHeight: 1.45}}>
                {pt}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export const SplitComparison: React.FC<SplitComparisonProps> = ({title, left, right}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const vs = spring({frame: frame - 22, fps, config: {damping: 12, stiffness: 160}});
  const titleIn = interpolate(frame, [10, 34], [0, 1], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});

  return (
    <AbsoluteFill style={{background: theme.background, flexDirection: 'row', overflow: 'hidden'}}>
      <Panel side={left} color={theme.primary} from="left" />
      <Panel side={right} color={theme.secondary} from="right" />

      <div
        style={{
          position: 'absolute',
          left: 960 - 1.5,
          top: 0,
          bottom: 0,
          width: 3,
          background: `linear-gradient(180deg, transparent, ${theme.text}, transparent)`,
          opacity: 0.35 * vs,
        }}
      />
      <div
        style={{
          position: 'absolute',
          left: 960 - 80,
          top: 540 - 80,
          width: 160,
          height: 160,
          borderRadius: 80,
          background: theme.background,
          border: `4px solid ${theme.text}`,
          display: 'flex',
          justifyContent: 'center',
          alignItems: 'center',
          fontFamily: theme.fontSans,
          fontWeight: 800,
          fontSize: 54,
          color: theme.text,
          transform: `scale(${vs})`,
          boxShadow: '0 0 60px rgba(255,255,255,0.18)',
        }}
      >
        বনাম
      </div>

      {title ? (
        <div
          style={{
            position: 'absolute',
            top: 48,
            width: '100%',
            textAlign: 'center',
            fontFamily: theme.fontSans,
            fontWeight: 600,
            fontSize: 44,
            color: theme.textDim,
            opacity: titleIn,
          }}
        >
          {title}
        </div>
      ) : null}
    </AbsoluteFill>
  );
};
