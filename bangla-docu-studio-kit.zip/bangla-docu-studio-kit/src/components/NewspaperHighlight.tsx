import React from 'react';
import {AbsoluteFill, Easing, interpolate, spring, useCurrentFrame, useVideoConfig} from 'remotion';
import {theme, withAlpha} from '../theme';
import type {NewspaperProps} from '../types';

const easeOut = Easing.bezier(0.16, 1, 0.3, 1);

export const NewspaperHighlight: React.FC<NewspaperProps> = ({headline, source, date, body, highlight}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();

  const paperIn = spring({frame, fps, config: {damping: 18, stiffness: 90}});
  const rotate = interpolate(paperIn, [0, 1], [-8, -1.5]);
  const scale = interpolate(frame, [0, 240], [1, 1.04], {extrapolateRight: 'clamp'});

  const hlProgress = interpolate(frame, [50, 85], [0, 1], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
    easing: easeOut,
  });

  const idx = highlight ? body.indexOf(highlight) : -1;
  const before = idx >= 0 ? body.slice(0, idx) : body;
  const hl = idx >= 0 ? highlight : '';
  const after = idx >= 0 ? body.slice(idx + highlight.length) : '';

  return (
    <AbsoluteFill style={{background: theme.background, justifyContent: 'center', alignItems: 'center'}}>
      <AbsoluteFill
        style={{background: `radial-gradient(ellipse at center, ${withAlpha(theme.primary, 0.14)}, transparent 65%)`}}
      />
      <div
        style={{
          width: 1380,
          padding: '56px 84px 72px',
          background: '#EFE7D6',
          backgroundImage:
            'repeating-linear-gradient(0deg, rgba(0,0,0,0.025) 0px, rgba(0,0,0,0.025) 2px, transparent 2px, transparent 5px)',
          color: '#1B1A17',
          boxShadow: '0 50px 120px rgba(0,0,0,0.65)',
          transform: `translateY(${(1 - paperIn) * 400}px) rotate(${rotate}deg) scale(${scale})`,
          opacity: Math.min(1, paperIn * 1.5),
          fontFamily: theme.fontSerif,
        }}
      >
        <div
          style={{
            display: 'flex',
            justifyContent: 'space-between',
            borderBottom: '3px double #1B1A17',
            paddingBottom: 14,
            fontSize: 30,
            fontWeight: 700,
            letterSpacing: 1,
          }}
        >
          <span>{source ?? theme.channelName}</span>
          <span>{date ?? ''}</span>
        </div>
        <div style={{fontSize: 84, fontWeight: 700, lineHeight: 1.3, margin: '34px 0 30px'}}>{headline}</div>
        <div style={{fontSize: 46, lineHeight: 1.8, fontWeight: 400}}>
          {before}
          <span style={{position: 'relative', display: 'inline'}}>
            <span
              style={{
                position: 'absolute',
                left: 0,
                right: 0,
                top: '8%',
                bottom: '4%',
                background: withAlpha(theme.primary, 0.55),
                transformOrigin: 'left center',
                transform: `scaleX(${hlProgress})`,
                borderRadius: 4,
              }}
            />
            <span style={{position: 'relative', fontWeight: 700}}>{hl}</span>
          </span>
          {after}
        </div>
      </div>
    </AbsoluteFill>
  );
};
