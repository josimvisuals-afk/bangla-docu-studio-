import React from 'react';
import {AbsoluteFill, Easing, interpolate, spring, useCurrentFrame, useVideoConfig} from 'remotion';
import {theme, withAlpha} from '../theme';
import type {KineticQuoteProps} from '../types';

const easeOut = Easing.bezier(0.16, 1, 0.3, 1);

export const KineticQuote: React.FC<KineticQuoteProps> = ({quote, author}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const words = quote.split(/\s+/).filter(Boolean);
  const STAGGER = 5;
  const lastWordFrame = 8 + words.length * STAGGER;

  const markIn = spring({frame, fps, config: {damping: 200}});
  const authorIn = interpolate(frame, [lastWordFrame + 6, lastWordFrame + 26], [0, 1], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
    easing: easeOut,
  });
  const drift = interpolate(frame, [0, 300], [0, -30], {extrapolateRight: 'clamp'});

  return (
    <AbsoluteFill style={{background: theme.background, justifyContent: 'center', padding: '0 170px'}}>
      <AbsoluteFill
        style={{background: `radial-gradient(ellipse at 20% 30%, ${withAlpha(theme.secondary, 0.16)}, transparent 55%)`}}
      />
      <div
        style={{
          position: 'absolute',
          left: 110,
          top: 90,
          fontFamily: theme.fontSerif,
          fontSize: 420,
          lineHeight: 1,
          color: theme.primary,
          opacity: 0.9 * markIn,
          transform: `scale(${0.6 + markIn * 0.4})`,
        }}
      >
        “
      </div>
      <div style={{transform: `translateY(${drift}px)`}}>
        <div
          style={{
            display: 'flex',
            flexWrap: 'wrap',
            gap: '0 26px',
            fontFamily: theme.fontSans,
            fontWeight: 800,
            fontSize: 92,
            lineHeight: 1.5,
            color: theme.text,
            maxWidth: 1580,
          }}
        >
          {words.map((w, i) => {
            const p = spring({frame: frame - 8 - i * STAGGER, fps, config: {damping: 16, stiffness: 140}});
            return (
              <span
                key={i}
                style={{
                  display: 'inline-block',
                  opacity: Math.min(1, p * 1.6),
                  transform: `translateY(${(1 - p) * 60}px)`,
                  filter: `blur(${(1 - p) * 8}px)`,
                }}
              >
                {w}
              </span>
            );
          })}
        </div>
        {author ? (
          <div
            style={{
              marginTop: 44,
              display: 'flex',
              alignItems: 'center',
              gap: 22,
              opacity: authorIn,
              transform: `translateX(${(1 - authorIn) * -30}px)`,
            }}
          >
            <div style={{width: 80, height: 6, background: theme.primary, borderRadius: 3}} />
            <div style={{fontFamily: theme.fontSans, fontSize: 46, color: theme.textDim, fontWeight: 600}}>
              {author}
            </div>
          </div>
        ) : null}
      </div>
    </AbsoluteFill>
  );
};
