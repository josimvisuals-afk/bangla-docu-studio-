import React from 'react';
import {Composition} from 'remotion';
import {Documentary} from './Documentary';
import timeline from './generated/scenes.json';
import type {GeneratedTimeline} from './types';

const data = timeline as unknown as GeneratedTimeline;

const totalFrames = Math.max(
  1,
  data.scenes.reduce((sum, s) => sum + s.durationInFrames, 0)
);

export const RemotionRoot: React.FC = () => {
  return (
    <Composition
      id="Documentary"
      component={Documentary}
      durationInFrames={totalFrames}
      fps={data.fps}
      width={1920}
      height={1080}
    />
  );
};
