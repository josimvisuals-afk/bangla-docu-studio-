import {continueRender, delayRender, staticFile} from 'remotion';
import brand from '../brand-config.json';

export type BrandConfig = {
  channelName: string;
  primaryColor: string;
  secondaryColor: string;
  backgroundColor: string;
  voice: 'bn-BD-PradeepNeural' | 'bn-BD-NabanitaNeural';
  voiceRate: string;
  voicePitch: string;
  watermarkText: string;
};

// Everything here comes from brand-config.json (the only file buyers must edit).
export const brandConfig = brand as BrandConfig;

// Fonts are bundled in public/fonts (Noto Sans/Serif Bengali, SIL OFL license), so rendering
// works offline and never depends on Google Fonts being reachable.
// Each script has its own file: the Bangla family covers Bangla glyphs, the "Latin" family covers
// English letters/digits (e.g. an @handle); the browser falls back from one to the other per character.
const FONT_FILES = [
  {family: 'BanglaSans', file: 'noto-sans-bengali-bengali', weights: ['400', '600', '800']},
  {family: 'BanglaSansLatin', file: 'noto-sans-bengali-latin', weights: ['400', '600', '800']},
  {family: 'BanglaSerif', file: 'noto-serif-bengali-bengali', weights: ['400', '700']},
  {family: 'BanglaSerifLatin', file: 'noto-serif-bengali-latin', weights: ['400', '700']},
];

if (typeof document !== 'undefined') {
  const handle = delayRender('Loading bundled Bangla fonts');
  Promise.all(
    FONT_FILES.flatMap((f) =>
      f.weights.map((weight) =>
        new FontFace(f.family, `url(${staticFile(`fonts/${f.file}-${weight}-normal.woff2`)})`, {
          weight,
          style: 'normal',
        })
          .load()
          .then((face) => {
            (document.fonts as unknown as {add: (f: FontFace) => void}).add(face);
          })
      )
    )
  )
    .catch((err) => {
      // Never block a render on fonts; the system fallback font is used instead.
      console.error('Could not load bundled fonts', err);
    })
    .finally(() => continueRender(handle));
}

export const theme = {
  channelName: brandConfig.channelName,
  watermarkText: brandConfig.watermarkText,
  primary: brandConfig.primaryColor,
  secondary: brandConfig.secondaryColor,
  background: brandConfig.backgroundColor,
  text: '#F5F5F7',
  textDim: 'rgba(245,245,247,0.62)',
  surface: 'rgba(255,255,255,0.06)',
  surfaceBorder: 'rgba(255,255,255,0.12)',
  fontSans: "'BanglaSans', 'BanglaSansLatin', 'Noto Sans Bengali', sans-serif",
  fontSerif: "'BanglaSerif', 'BanglaSerifLatin', 'Noto Serif Bengali', serif",
} as const;

/** "#RRGGBB" + alpha (0-1) -> rgba() string. Lets brand colors drive glows and tints. */
export const withAlpha = (hex: string, alpha: number): string => {
  const clean = hex.replace('#', '');
  const full =
    clean.length === 3
      ? clean
          .split('')
          .map((c) => c + c)
          .join('')
      : clean;
  const r = parseInt(full.slice(0, 2), 16);
  const g = parseInt(full.slice(2, 4), 16);
  const b = parseInt(full.slice(4, 6), 16);
  return `rgba(${r},${g},${b},${alpha})`;
};

const BN_DIGITS = ['০', '১', '২', '৩', '৪', '৫', '৬', '৭', '৮', '৯'];

/** Convert western digits in a number/string to Bangla digits: 1971 -> ১৯৭১ */
export const toBn = (value: number | string): string =>
  String(value).replace(/\d/g, (d) => BN_DIGITS[Number(d)]);
