#!/usr/bin/env bash
# Bangla Docu Studio Kit - one-click setup for Mac / Linux / GitHub Codespaces
# Usage:  bash setup.sh
set -e
cd "$(dirname "$0")"

echo "=== Bangla Docu Studio Kit setup ==="

if ! command -v node >/dev/null 2>&1; then
  echo "ERROR: Node.js is not installed. Install the LTS version from https://nodejs.org and run this again."
  exit 1
fi
echo "Node: $(node -v)"

PY=""
for c in python3 python; do
  if command -v "$c" >/dev/null 2>&1; then PY="$c"; break; fi
done
if [ -z "$PY" ]; then
  echo "ERROR: Python 3 is not installed. Install it from https://www.python.org/downloads/ and run this again."
  exit 1
fi
echo "Python: $($PY --version)"

echo
echo "[1/2] Installing video engine (npm install)..."
npm install

echo
echo "[2/2] Installing voice tools (pip install edge-tts mutagen)..."
if ! "$PY" -m pip install --quiet edge-tts mutagen 2>/dev/null; then
  # Newer Linux/Mac Pythons block system-wide installs; this flag is the standard workaround.
  "$PY" -m pip install --quiet --break-system-packages edge-tts mutagen
fi

if [ ! -f .env ] && [ -f .env.example ]; then
  cp .env.example .env
  echo "Created .env from .env.example (API keys are optional)."
fi

echo
echo "=== Setup complete! ==="
echo "Preview the sample video:   npm run studio"
echo "Render the sample video:    npm run demo      (creates out/sample_demo.mp4)"
echo "Edit your brand:            open brand-config.json"
