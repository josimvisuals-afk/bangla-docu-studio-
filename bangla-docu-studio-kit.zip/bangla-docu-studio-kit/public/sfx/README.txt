SOUND EFFECTS FOLDER / সাউন্ড ইফেক্ট ফোল্ডার
==========================================

Drop your royalty-free sound files into THIS folder, using EXACTLY these filenames
(all lowercase, .mp3 format):

    whoosh.mp3        short swoosh (0.3 - 1 sec). Plays at the start of most scenes.
    riser.mp3         building tension sound (2 - 4 sec). Plays at the start of quote and map scenes.
    paper_flip.mp3    paper / page flip (0.5 - 1 sec). Plays at the start of newspaper scenes.
    bg_dark.mp3       dark ambient background music. Loops quietly under the whole video (low volume).

The files are NOT included (so you can use sounds you have a license for).
A missing file is safely skipped: the video still renders, just without that sound.

Rules
-----
- Keep the names exactly as above. Do not rename, do not use .wav (convert to .mp3 first).
- Volume is set in the code (bg_dark.mp3 is played at about 12%), so you do not need to lower it yourself.
- Use only sounds whose license allows commercial use and YouTube/social media monetization.

Where to find free sounds (check each file's license before using)
------------------------------------------------------------------
- Pixabay Sound Effects / Music  https://pixabay.com/sound-effects/
- Mixkit                         https://mixkit.co/free-sound-effects/
- Freesound (filter: CC0)        https://freesound.org/

বাংলায় সংক্ষেপে
----------------
উপরের ৪টি ফাইল ঠিক এই নামে (ছোট হাতের অক্ষরে, .mp3) এই ফোল্ডারে রাখুন। ফাইল না থাকলে ভিডিও
ঠিকই রেন্ডার হবে, শুধু ওই সাউন্ডটি বাজবে না। শুধু সেই সাউন্ডই ব্যবহার করুন যার লাইসেন্স বাণিজ্যিক
ব্যবহারের অনুমতি দেয়।
