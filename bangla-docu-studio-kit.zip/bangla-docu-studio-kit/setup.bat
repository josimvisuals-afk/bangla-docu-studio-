@echo off
REM Bangla Docu Studio Kit - one-click setup for Windows
REM Double-click this file, or run:  setup.bat
cd /d "%~dp0"

echo === Bangla Docu Studio Kit setup ===

where node >nul 2>nul
if errorlevel 1 (
  echo ERROR: Node.js is not installed. Install the LTS version from https://nodejs.org and run this again.
  pause
  exit /b 1
)
for /f "delims=" %%v in ('node -v') do echo Node: %%v

set PYCMD=
where python >nul 2>nul && set PYCMD=python
if "%PYCMD%"=="" (
  where py >nul 2>nul && set PYCMD=py
)
if "%PYCMD%"=="" (
  echo ERROR: Python 3 is not installed. Install it from https://www.python.org/downloads/
  echo        and tick "Add python.exe to PATH" during installation. Then run this again.
  pause
  exit /b 1
)
echo Python command: %PYCMD%

echo.
echo [1/2] Installing video engine (npm install)...
call npm install
if errorlevel 1 (
  echo ERROR: npm install failed. Check your internet connection and try again.
  pause
  exit /b 1
)

echo.
echo [2/2] Installing voice tools (pip install edge-tts mutagen)...
%PYCMD% -m pip install edge-tts mutagen
if errorlevel 1 (
  echo ERROR: pip install failed. Check your internet connection and try again.
  pause
  exit /b 1
)

if not exist .env (
  if exist .env.example (
    copy .env.example .env >nul
    echo Created .env from .env.example ^(API keys are optional^).
  )
)

echo.
echo === Setup complete! ===
echo Preview the sample video:   npm run studio
echo Render the sample video:    npm run demo      (creates out\sample_demo.mp4)
echo Edit your brand:            open brand-config.json
pause
