# 🎬 Bangla Docu Studio Kit

**বাংলায় ডকুমেন্টারি ভিডিও বানান — কোডিং ছাড়াই।** · **Make Bangla documentary videos — no coding needed.**

[বাংলা](#-বাংলা-নির্দেশিকা) · [English](#-english-guide)

![scenes](https://img.shields.io/badge/scenes-7-FF5722) ![voice](https://img.shields.io/badge/voice-Bangla%20(free)-00BFA5) ![engine](https://img.shields.io/badge/engine-Remotion-0E0E10)

| 7টি সিন / 7 scenes | কাজ / What it does |
|---|---|
| `parallax` | ওপেনিং/চ্যাপ্টার টাইটেল · Opening / chapter title |
| `newspaper` | হাইলাইটসহ পত্রিকার শিরোনাম · Newspaper headline with highlight |
| `quote` | অ্যানিমেটেড উক্তি · Kinetic quote |
| `chart` | অ্যানিমেটেড বার চার্ট · Animated bar chart |
| `timeline` | ঐতিহাসিক টাইমলাইন · Historical timeline |
| `comparison` | আগে বনাম পরে / ক বনাম খ · Split-screen comparison |
| `map` | ডার্ক ম্যাপ জুম + গ্লোয়িং পিন · Dark map zoom with glowing pin |

---

# 🇧🇩 বাংলা নির্দেশিকা

## ১. ২ মিনিটে সেটআপ

আপনার লাগবে: **[Node.js](https://nodejs.org)** (LTS ভার্সন) এবং **[Python 3](https://www.python.org/downloads/)**।
(Windows-এ Python ইনস্টলের সময় **"Add python.exe to PATH"** টিক দিন।)

### 💻 পিসিতে (Windows)
1. জিপ ফাইলটি Extract করুন।
2. `setup.bat` ফাইলে **ডাবল-ক্লিক** করুন। এটি নিজেই সব ইনস্টল করবে।
3. শেষ হলে টার্মিনালে লিখুন: `npm run studio` — ব্রাউজারে ভিডিও প্রিভিউ খুলবে।

### 🍎 Mac / Linux
```bash
bash setup.sh
npm run studio
```

### 📱 মোবাইলে (GitHub Codespaces)
1. [github.com](https://github.com)-এ বিনামূল্যে অ্যাকাউন্ট খুলুন, **New repository** বানিয়ে এই ফোল্ডারের সব ফাইল আপলোড করুন।
2. রিপোজিটরিতে **Code → Codespaces → Create codespace on main** চাপুন (ফোনের ব্রাউজারে "Desktop site" চালু রাখলে সহজ হয়)।
3. নিচের টার্মিনালে লিখুন: `bash setup.sh`
4. তারপর: `npm run studio` — "Open in Browser" বাটনে চাপলে প্রিভিউ দেখা যাবে।

> প্রথমবার রেন্ডারের সময় Remotion একবার Chrome ডাউনলোড করে — ইন্টারনেট চালু রাখুন।

### ✅ প্রথম ভিডিও (নমুনা)
```bash
npm run demo
```
কিছুক্ষণ পর `out/sample_demo.mp4` তৈরি হবে — ঢাকা নিয়ে ৭টি সিনের নমুনা ডকুমেন্টারি।

## ২. `brand-config.json` কাস্টমাইজ করুন

এই একটি ফাইলই আপনার চ্যানেলের ব্র্যান্ড ঠিক করে — ভিডিওর রং, নাম, ওয়াটারমার্ক ও ভয়েস। ফাইলটি Notepad-এ খুলে ডাবল-কোটের ভেতরের লেখা বদলান।

```json
{
  "channelName": "আমার চ্যানেল",
  "primaryColor": "#FF5722",
  "secondaryColor": "#00BFA5",
  "backgroundColor": "#0E0E10",
  "voice": "bn-BD-PradeepNeural",
  "voiceRate": "+0%",
  "voicePitch": "+0Hz",
  "watermarkText": "@amar_channel"
}
```

| ফিল্ড | কী বদলায় | উদাহরণ |
|---|---|---|
| `channelName` | বাঁ-উপরের কোণে চ্যানেলের নাম | `"সত্যের সন্ধানে"` |
| `primaryColor` | প্রধান রং (হাইলাইট, পিন, টাইমলাইন) | `"#FF5722"` |
| `secondaryColor` | দ্বিতীয় রং (চার্ট, নদী, ডান প্যানেল) | `"#00BFA5"` |
| `backgroundColor` | ব্যাকগ্রাউন্ড রং | `"#0E0E10"` |
| `voice` | `bn-BD-PradeepNeural` (পুরুষ) অথবা `bn-BD-NabanitaNeural` (নারী) | |
| `voiceRate` | কথা বলার গতি: `"+10%"` দ্রুত, `"-10%"` ধীর | `"-5%"` |
| `voicePitch` | কণ্ঠের সুর: `"+5Hz"` চড়া, `"-5Hz"` খাদ | `"+0Hz"` |
| `watermarkText` | ডান-নিচের কোণে ওয়াটারমার্ক (ফাঁকা রাখলে বন্ধ) | `"@my_channel"` |

রঙের কোড হতে হবে `#` দিয়ে শুরু ৬ অক্ষরের হেক্স কোড। ভয়েস বদলালে `npm run voice` আবার চালান।

## ৩. `/bangla-docu "বিষয়"` দিয়ে ভিডিও বানান

এই কিটে [Claude Code](https://claude.com/claude-code)-এর জন্য একটি রেডিমেড স্কিল আছে (`.claude/skills/bangla-docu`)।

1. টার্মিনালে প্রজেক্ট ফোল্ডারে Claude Code চালু করুন।
2. লিখুন:
   ```
   /bangla-docu "ঢাকার ইতিহাস"
   ```
3. Claude নিজে তথ্য খুঁজবে, বাংলা স্ক্রিপ্ট লিখবে, ভয়েস বানাবে এবং `out/` ফোল্ডারে MP4 রেন্ডার করবে।

### Claude Code ছাড়া (ম্যানুয়ালি)
1. `script/script.json` খুলুন (নমুনা: `script/sample_script.json`) — প্রতিটি সিনে `type`, `narration` (বাংলা বর্ণনা) ও `props` লিখুন।
2. `npm run voice` — বাংলা ভয়েস ও টাইমিং তৈরি হবে।
3. `npm run render` — ভিডিও পাবেন `out/video.mp4`-তে।

প্রতিটি সিনের `props` কেমন হবে তা `.claude/skills/bangla-docu/SKILL.md`-তে উদাহরণসহ দেওয়া আছে।

## ৪. সাউন্ড ইফেক্ট (ঐচ্ছিক)
`public/sfx/` ফোল্ডারে `whoosh.mp3`, `riser.mp3`, `paper_flip.mp3`, `bg_dark.mp3` নামে ফাইল রাখুন। না রাখলেও ভিডিও রেন্ডার হবে। বিস্তারিত: `public/sfx/README.txt`।

## ৫. সমস্যা হলে

| সমস্যা | সমাধান |
|---|---|
| `VOICE FAILED` দেখাচ্ছে | ইন্টারনেট চেক করুন, তারপর `npm run voice` আবার চালান। ভয়েস ছাড়া ভিডিও নীরব হবে। |
| `node`/`python` পাওয়া যাচ্ছে না | Node.js ও Python ইনস্টল করে টার্মিনাল বন্ধ করে আবার খুলুন। |
| রেন্ডার ধীর | অন্য অ্যাপ বন্ধ করুন; ছোট স্ক্রিপ্ট দিয়ে শুরু করুন। |
| বাংলা ফন্ট ভাঙা | `public/fonts/` ফোল্ডার মুছবেন না — ফন্ট ভেতরেই দেওয়া আছে। |

---

# 🇬🇧 English Guide

## 1. Set up in 2 minutes

You need **[Node.js](https://nodejs.org)** (LTS) and **[Python 3](https://www.python.org/downloads/)**.
(On Windows, tick **"Add python.exe to PATH"** when installing Python.)

### 💻 PC (Windows)
1. Unzip the kit.
2. **Double-click `setup.bat`**. It installs everything for you.
3. Then run `npm run studio` to preview in your browser.

### 🍎 Mac / Linux
```bash
bash setup.sh
npm run studio
```

### 📱 Mobile (via GitHub Codespaces)
1. Create a free account at [github.com](https://github.com), make a **New repository**, and upload all the files from this kit.
2. On the repo page choose **Code → Codespaces → Create codespace on main** (turn on "Desktop site" in your phone browser if needed).
3. In the terminal at the bottom, run: `bash setup.sh`
4. Then run `npm run studio` and tap **Open in Browser** to preview.

> The first render downloads a Chrome build once — keep your internet on.

### ✅ Your first video (sample)
```bash
npm run demo
```
This generates the voice and renders `out/sample_demo.mp4` — a 7-scene sample documentary about Dhaka.

## 2. Customize `brand-config.json`

One file controls your whole brand. Open it in any text editor and change the values between the quotes.

| Field | Controls | Example |
|---|---|---|
| `channelName` | Channel name tag, top-left | `"My Channel"` |
| `primaryColor` | Main accent (highlights, pin, timeline) — default `#FF5722` | `"#FF5722"` |
| `secondaryColor` | Second accent (charts, rivers, right panel) — default `#00BFA5` | `"#00BFA5"` |
| `backgroundColor` | Background — default `#0E0E10` | `"#0E0E10"` |
| `voice` | `bn-BD-PradeepNeural` (male) or `bn-BD-NabanitaNeural` (female) | |
| `voiceRate` | Speaking speed: `"+10%"` faster, `"-10%"` slower | `"-5%"` |
| `voicePitch` | Voice pitch: `"+5Hz"` higher, `"-5Hz"` lower | `"+0Hz"` |
| `watermarkText` | Watermark, bottom-right (empty = hidden) | `"@my_channel"` |

Colors must be 6-digit hex codes starting with `#`. After changing the voice settings, run `npm run voice` again.

## 3. Generate a video with `/bangla-docu "Topic"`

The kit includes a ready-made skill for [Claude Code](https://claude.com/claude-code) (`.claude/skills/bangla-docu`).

1. Start Claude Code in the project folder.
2. Type:
   ```
   /bangla-docu "History of Dhaka"
   ```
3. Claude researches the topic, writes the Bangla script, generates the voiceover and renders an MP4 into `out/`.

### Without Claude Code (manual)
1. Edit `script/script.json` (see `script/sample_script.json`): each scene has a `type`, Bangla `narration`, and `props`.
2. `npm run voice` — generates Bangla narration and exact timing.
3. `npm run render` — your video appears at `out/video.mp4`.

The `props` for every scene type are documented with examples in `.claude/skills/bangla-docu/SKILL.md`.

## 4. Sound effects (optional)
Drop `whoosh.mp3`, `riser.mp3`, `paper_flip.mp3` and `bg_dark.mp3` into `public/sfx/`. Missing files are skipped safely. Details: `public/sfx/README.txt`.

## 5. Optional API keys
Copy `.env.example` to `.env` (setup does this for you). Keys are **not** required — the free Microsoft Edge Bangla voices work out of the box.
- `ELEVENLABS_API_KEY` + `ELEVENLABS_VOICE_ID` → premium voices: `python3 scripts/generate_voice.py --engine elevenlabs`
- `PEXELS_API_KEY` → free stock photos: `python3 scripts/fetch_pexels.py "Dhaka skyline" dhaka.jpg`, then use `"imageSrc": "images/dhaka.jpg"` in a `parallax` scene.

## 6. Troubleshooting

| Problem | Fix |
|---|---|
| `VOICE FAILED` | Check your internet, then run `npm run voice` again. Without it the video renders silent. |
| `node` / `python` not found | Install Node.js and Python, then close and reopen the terminal. |
| Slow render | Close other apps; start with a short script. |
| Broken Bangla text | Don't delete `public/fonts/` — the fonts are bundled there (SIL OFL licensed). |

## What's inside

```
brand-config.json        ← your brand (edit this)
script/script.json       ← your video script
src/Documentary.tsx      ← scene router + branding + audio
src/components/          ← the 7 scene components
src/theme.ts             ← reads brand-config.json
scripts/generate_voice.py← Bangla voiceover + timing
public/sfx/              ← drop-in sound effects
public/fonts/            ← bundled Bangla fonts (Noto, OFL)
.claude/skills/bangla-docu/SKILL.md
setup.sh · setup.bat     ← one-click setup
```

## Notes
- Data in the sample video (population numbers, newspaper text) is **sample data** and clearly labeled; replace it with verified facts in your own videos.
- The map scene is a stylized abstract map, not an accurate cartographic outline.
- Music and sound effects are not included; use only files you are licensed to use commercially.
- Built on [Remotion](https://www.remotion.dev). Remotion has its own license terms for commercial use by companies — see remotion.dev/license.
