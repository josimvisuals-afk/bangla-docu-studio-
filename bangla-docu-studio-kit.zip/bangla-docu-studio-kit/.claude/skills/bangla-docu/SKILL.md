---
name: bangla-docu
description: Create a complete Bangla documentary video (research, Bangla narration, scene design, voiceover, render) from a topic. Use when the user types /bangla-docu "Topic" or asks for a Bangla documentary / explainer video in this project.
argument-hint: "Topic"
---

# Bangla Docu — topic in, finished video out

The topic is the text after the command (for example `/bangla-docu "ঢাকার ইতিহাস"`).
If no topic is given, ask for one short topic and nothing else.

You are working inside the Bangla Docu Studio Kit (a Remotion project). Brand colors, voice and
watermark live in `brand-config.json` — **never hard-code them and do not edit that file unless the user asks.**

## Workflow (do these in order)

1. **Research.** If web search is available, gather 5–8 reliable facts, dates and (if relevant) real numbers about the topic.
   Never invent statistics, quotes, dates or sources. If you cannot verify a number, leave the chart/newspaper out or
   label it clearly as sample data (e.g. title ends with "(নমুনা তথ্য)").
2. **Write the script** to `script/script.json` (format below). Target 60–120 seconds: **8–14 scenes**.
3. **Generate voice + timing:** run `npm run voice`. This writes `public/audio/scene_XX.mp3` and `src/generated/scenes.json`.
   - If it prints `VOICE FAILED`, the internet or TTS service is unreachable. Tell the user, and offer to retry. Do not pretend the video has narration.
4. **Type-check (optional but quick):** `npx tsc --noEmit`.
5. **Render:** `npx remotion render src/index.ts Documentary out/<short-english-slug>.mp4`
6. Tell the user the output path, the video length, and any scene where data was sample/unverified. Keep it to a few lines.

## script/script.json format

```json
{
  "title": "ভিডিওর শিরোনাম",
  "scenes": [
    { "type": "<scene type>", "narration": "বাংলা বর্ণনা…", "props": { … } }
  ]
}
```

- `narration` is spoken aloud by the voice in `brand-config.json`. The scene lasts exactly as long as the narration (+ a short pause).
- Write narration in **natural spoken Bangla**: short sentences, 1–3 sentences per scene (about 8–35 words). No English words unless unavoidable.
- Props text is shown on screen: keep it short. Use Bangla digits (০১২৩৪৫৬৭৮৯) for years and numbers in labels.

## The 7 scene types

### 1. `parallax` — opening / chapter title
```json
{"type":"parallax","props":{"title":"ঢাকা: নদীর শহরের গল্প","subtitle":"ছোট জনপদ থেকে মহানগর","imageSrc":"images/dhaka.jpg"}}
```
`imageSrc` is optional (file inside `public/`). Omit it for the built-in animated background. Title ≤ 7 words.
Use for scene 1 and for chapter breaks.

### 2. `newspaper` — a headline / quoted document with a highlighted phrase
```json
{"type":"newspaper","props":{"headline":"…","source":"পত্রিকার নাম","date":"তারিখ","body":"১–২ বাক্য…","highlight":"body-র ভেতরের হুবহু অংশ"}}
```
`highlight` **must be an exact substring of `body`** (same spelling and spacing), otherwise nothing is highlighted.
Only use a real source/date if you verified it; otherwise write "নমুনা সংবাদ".

### 3. `quote` — kinetic typography quote
```json
{"type":"quote","props":{"quote":"উক্তি (১৮ শব্দের মধ্যে)","author":"বক্তার নাম"}}
```
Only attribute a quote to a real person if you verified it. Good as the final scene.

### 4. `chart` — animated horizontal bar chart
```json
{"type":"chart","props":{"title":"শিরোনাম","unit":"লক্ষ","source":"সূত্র","items":[{"label":"১৯৯০","value":66},{"label":"২০১০","value":146}]}}
```
2–7 items. `value` is a plain number (the screen shows it in Bangla digits). The largest bar is highlighted automatically.
`label` is shown as written, so type Bangla digits yourself.

### 5. `timeline` — animated historical timeline (Vox style)
```json
{"type":"timeline","props":{"title":"শিরোনাম","orientation":"horizontal","events":[{"date":"১৬১০","title":"ঘটনা","description":"এক লাইনের ব্যাখ্যা"}]}}
```
`orientation`: `"horizontal"` (max 5 events) or `"vertical"` (max 4 events). `date` is auto-converted to Bangla digits.
Keep `title` ≤ 5 words and `description` ≤ 8 words. Optional `description`.

### 6. `comparison` — split screen A vs B ("বনাম")
```json
{"type":"comparison","props":{"title":"আগে বনাম পরে","left":{"label":"আগে","value":"ঐচ্ছিক","points":["…","…"]},"right":{"label":"পরে","points":["…","…"]}}}
```
Left uses the primary color, right the secondary. 2–4 short points per side. `value` and `title` are optional.

### 7. `map` — dark stylized map zoom with glowing pin
```json
{"type":"map","props":{"locationLabel":"ঢাকা","subLabel":"বুড়িগঙ্গার তীরে","pinX":56,"pinY":52,"zoom":2.6}}
```
`pinX`/`pinY` are 0–100 (percent). The map is an abstract stylized backdrop, not a real cartographic outline — never imply it
shows real borders. Vary pin position between map scenes. `zoom` 2–3.

## Storytelling rules

- Scene 1 = `parallax` hook. Last scene = `quote` or a closing `parallax`.
- Never use the same scene type twice in a row; mix all types that fit the topic (don't force a map or chart if there is no real data/place).
- Order: hook → context → turning points (`timeline`) → evidence (`newspaper`, `chart`) → tension (`comparison`) → closing line.
- Narration should carry the story; on-screen text only supports it.

## Do not

- Do not edit `src/` components or `brand-config.json` unless the user asks for it.
- Do not commit `.env`, `out/` or `node_modules/`.
- Do not claim the video is finished until the render command succeeded.
