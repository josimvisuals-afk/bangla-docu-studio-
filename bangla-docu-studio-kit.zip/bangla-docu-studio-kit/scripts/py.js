// Runs a Python script with whichever Python launcher exists (python3, python, or py on Windows).
// Usage: node scripts/py.js scripts/generate_voice.py [args...]
const {spawnSync} = require('child_process');

const args = process.argv.slice(2);
const candidates = ['python3', 'python', 'py'];

for (const cmd of candidates) {
  const probe = spawnSync(cmd, ['--version'], {stdio: 'ignore'});
  if (probe.error || probe.status !== 0) continue;
  const run = spawnSync(cmd, args, {stdio: 'inherit'});
  process.exit(run.status === null ? 1 : run.status);
}

console.error('Python was not found. Install Python 3 from https://www.python.org/downloads/ and try again.');
process.exit(1);
