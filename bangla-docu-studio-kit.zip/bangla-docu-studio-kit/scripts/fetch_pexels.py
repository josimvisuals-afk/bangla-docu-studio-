#!/usr/bin/env python3
"""
Optional helper: download one free landscape stock photo from Pexels into public/images/.

Usage:
    python3 scripts/fetch_pexels.py "Dhaka skyline" dhaka.jpg

Needs PEXELS_API_KEY in .env (free key: https://www.pexels.com/api/).
Then use it in a parallax scene:  "imageSrc": "images/dhaka.jpg"
Pexels photos are free to use, but crediting the photographer is appreciated (printed below).
"""
import json
import os
import sys
import urllib.parse
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent


def load_env() -> None:
    env_path = ROOT / ".env"
    if not env_path.exists():
        return
    for line in env_path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, _, value = line.partition("=")
        os.environ.setdefault(key.strip(), value.strip().strip('"').strip("'"))


def main() -> int:
    if len(sys.argv) < 3:
        print('Usage: python3 scripts/fetch_pexels.py "search words" output_name.jpg')
        return 1
    query, name = sys.argv[1], sys.argv[2]
    load_env()
    key = os.environ.get("PEXELS_API_KEY", "").strip()
    if not key:
        print("ERROR: set PEXELS_API_KEY in .env first (free key from https://www.pexels.com/api/).")
        return 1

    url = "https://api.pexels.com/v1/search?" + urllib.parse.urlencode(
        {"query": query, "per_page": 1, "orientation": "landscape"}
    )
    try:
        req = urllib.request.Request(url, headers={"Authorization": key, "User-Agent": "bangla-docu-studio-kit"})
        with urllib.request.urlopen(req, timeout=30) as resp:
            data = json.loads(resp.read().decode("utf-8"))
        photos = data.get("photos", [])
        if not photos:
            print(f"No photo found for '{query}'. Try different words.")
            return 1
        photo = photos[0]
        img_url = photo["src"].get("large2x") or photo["src"]["original"]
        out_dir = ROOT / "public" / "images"
        out_dir.mkdir(parents=True, exist_ok=True)
        out = out_dir / name
        img_req = urllib.request.Request(img_url, headers={"User-Agent": "bangla-docu-studio-kit"})
        with urllib.request.urlopen(img_req, timeout=60) as resp:
            out.write_bytes(resp.read())
    except Exception as e:  # network, bad key, etc.
        print(f"ERROR: could not download the photo ({type(e).__name__}: {e})")
        return 1

    print(f"Saved {out.relative_to(ROOT)}")
    print(f"Photo by {photo.get('photographer', 'unknown')} on Pexels: {photo.get('url', '')}")
    print(f'Use it with:  "imageSrc": "images/{name}"')
    return 0


if __name__ == "__main__":
    sys.exit(main())
