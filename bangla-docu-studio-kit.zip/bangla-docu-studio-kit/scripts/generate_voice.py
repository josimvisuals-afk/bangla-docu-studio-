#!/usr/bin/env python3
"""
Bangla Docu Studio Kit - voice generator.

Reads  : script/script.json  (scenes + Bangla narration)
         brand-config.json   (voice, voiceRate, voicePitch)
Writes : public/audio/scene_XX.mp3        (one narration file per scene)
         src/generated/scenes.json        (scene list + exact durations for Remotion)

Usage:
    python3 scripts/generate_voice.py                       # uses script/script.json
    python3 scripts/generate_voice.py --script script/sample_script.json
    python3 scripts/generate_voice.py --engine elevenlabs   # needs keys in .env
    python3 scripts/generate_voice.py --no-voice            # silent preview, estimated timing
"""
import argparse
import asyncio
import json
import math
import os
import sys
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
AUDIO_DIR = ROOT / "public" / "audio"
OUT_JSON = ROOT / "src" / "generated" / "scenes.json"

VALID_TYPES = {"parallax", "newspaper", "quote", "chart", "timeline", "comparison", "map"}
VALID_VOICES = {"bn-BD-PradeepNeural", "bn-BD-NabanitaNeural"}
FPS = 30
MIN_SCENE_SECONDS = 4.0
TAIL_SECONDS = 0.8  # breathing room after narration ends


def load_env() -> None:
    """Tiny .env loader (no extra dependency). Existing environment variables win."""
    env_path = ROOT / ".env"
    if not env_path.exists():
        return
    for line in env_path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, _, value = line.partition("=")
        os.environ.setdefault(key.strip(), value.strip().strip('"').strip("'"))


def load_json(path: Path) -> dict:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except FileNotFoundError:
        sys.exit(f"ERROR: file not found: {path}")
    except json.JSONDecodeError as e:
        sys.exit(f"ERROR: {path.name} is not valid JSON (line {e.lineno}, column {e.colno}): {e.msg}")


def estimate_seconds(text: str) -> float:
    """Rough Bangla narration length when no audio exists (about 2.4 words per second)."""
    words = len(text.split())
    return max(MIN_SCENE_SECONDS, words / 2.4 + TAIL_SECONDS)


def mp3_seconds(path: Path) -> float:
    from mutagen.mp3 import MP3

    return float(MP3(str(path)).info.length)


async def edge_tts_save(text: str, out: Path, voice: str, rate: str, pitch: str) -> None:
    import edge_tts

    communicate = edge_tts.Communicate(text, voice, rate=rate, pitch=pitch)
    await communicate.save(str(out))


def elevenlabs_save(text: str, out: Path) -> None:
    api_key = os.environ.get("ELEVENLABS_API_KEY", "").strip()
    voice_id = os.environ.get("ELEVENLABS_VOICE_ID", "").strip()
    if not api_key or not voice_id:
        raise RuntimeError("ELEVENLABS_API_KEY and ELEVENLABS_VOICE_ID must be set in .env")
    req = urllib.request.Request(
        f"https://api.elevenlabs.io/v1/text-to-speech/{voice_id}",
        data=json.dumps({"text": text, "model_id": "eleven_multilingual_v2"}).encode("utf-8"),
        headers={"xi-api-key": api_key, "Content-Type": "application/json", "Accept": "audio/mpeg"},
        method="POST",
    )
    with urllib.request.urlopen(req, timeout=120) as resp:
        out.write_bytes(resp.read())


def synthesize(text: str, out: Path, engine: str, voice: str, rate: str, pitch: str) -> None:
    if engine == "elevenlabs":
        elevenlabs_save(text, out)
    else:
        asyncio.run(edge_tts_save(text, out, voice, rate, pitch))


def main() -> int:
    parser = argparse.ArgumentParser(description="Generate Bangla narration + timing for Remotion.")
    parser.add_argument("--script", default="script/script.json", help="path to the script JSON")
    parser.add_argument("--engine", choices=["edge", "elevenlabs"], default="edge")
    parser.add_argument("--no-voice", action="store_true", help="skip TTS; use estimated timing")
    parser.add_argument("--strict", action="store_true", help="exit with an error if any narration fails")
    args = parser.parse_args()

    load_env()
    brand = load_json(ROOT / "brand-config.json")
    voice = brand.get("voice", "bn-BD-PradeepNeural")
    rate = brand.get("voiceRate", "+0%")
    pitch = brand.get("voicePitch", "+0Hz")
    if voice not in VALID_VOICES:
        print(f"WARNING: voice '{voice}' is not one of {sorted(VALID_VOICES)}; using bn-BD-PradeepNeural")
        voice = "bn-BD-PradeepNeural"

    script_path = (ROOT / args.script) if not os.path.isabs(args.script) else Path(args.script)
    script = load_json(script_path)
    scenes = script.get("scenes")
    if not isinstance(scenes, list) or not scenes:
        sys.exit("ERROR: the script needs a non-empty 'scenes' list.")

    if not args.no_voice and args.engine == "edge":
        try:
            import edge_tts  # noqa: F401
            import mutagen  # noqa: F401
        except ImportError:
            sys.exit("ERROR: missing packages. Run:  pip install edge-tts mutagen   (or run setup.sh / setup.bat)")

    AUDIO_DIR.mkdir(parents=True, exist_ok=True)
    for old in AUDIO_DIR.glob("scene_*.mp3"):
        old.unlink()

    print(f"Voice: {voice}  rate={rate}  pitch={pitch}  engine={args.engine}")
    out_scenes = []
    failures = 0

    for i, scene in enumerate(scenes, start=1):
        stype = scene.get("type")
        if stype not in VALID_TYPES:
            sys.exit(f"ERROR: scene {i} has unknown type '{stype}'. Valid types: {sorted(VALID_TYPES)}")
        props = scene.get("props")
        if not isinstance(props, dict):
            sys.exit(f"ERROR: scene {i} ('{stype}') needs a 'props' object.")
        narration = (scene.get("narration") or "").strip()

        audio_rel = None
        seconds = estimate_seconds(narration) if narration else 5.0

        if narration and not args.no_voice:
            out_file = AUDIO_DIR / f"scene_{i:02d}.mp3"
            ok = False
            last_err = None
            for attempt in range(2):
                try:
                    synthesize(narration, out_file, args.engine, voice, rate, pitch)
                    seconds = max(MIN_SCENE_SECONDS, mp3_seconds(out_file) + TAIL_SECONDS)
                    audio_rel = f"audio/scene_{i:02d}.mp3"
                    ok = True
                    break
                except Exception as e:  # network, API key, etc.
                    last_err = e
            if ok:
                print(f"  scene {i:02d} [{stype}] {seconds:4.1f}s  voice OK")
            else:
                failures += 1
                if out_file.exists():
                    out_file.unlink()
                print(f"  scene {i:02d} [{stype}] {seconds:4.1f}s  VOICE FAILED ({type(last_err).__name__}: {last_err})")
        else:
            print(f"  scene {i:02d} [{stype}] {seconds:4.1f}s  (no narration audio)")

        out_scenes.append(
            {
                "type": stype,
                "props": props,
                "narration": narration,
                "audio": audio_rel,
                "durationInFrames": int(math.ceil(seconds * FPS)),
            }
        )

    OUT_JSON.parent.mkdir(parents=True, exist_ok=True)
    OUT_JSON.write_text(
        json.dumps({"title": script.get("title", ""), "fps": FPS, "scenes": out_scenes}, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    total = sum(s["durationInFrames"] for s in out_scenes) / FPS
    print(f"\nWrote {OUT_JSON.relative_to(ROOT)}  ({len(out_scenes)} scenes, {total:.1f}s total)")

    if failures:
        print(
            f"\n!! {failures} scene(s) have NO narration audio (check your internet connection / API keys).\n"
            "!! The video will still render, but those scenes will be silent. Re-run this script to retry."
        )
        if args.strict:
            return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
